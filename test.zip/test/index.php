<!doctype html>
<html lang="fr">

<head>
    <meta charset="utf-8">
    <title>Titre de la page</title>
    <link rel="stylesheet" href="style.css">
    <script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.4.1.min.js"></script>
    <script async src="test.js"></script>
</head>

<body>
    <main id="main">
        <button id="but">Click</button>
        <aricle>
            <a href="#" id="partiart1">article1</a>
        </aricle>
        <aricle>
            <a href="#" id="partiart2">article2</a>
        </aricle>
        <aricle>
            <a href="#" id="partiart3">article3</a>
        </aricle>
        <aricle>
            <a href="#" id="partiart4">article4</a>
        </aricle>
    </main>
</body>

</html>